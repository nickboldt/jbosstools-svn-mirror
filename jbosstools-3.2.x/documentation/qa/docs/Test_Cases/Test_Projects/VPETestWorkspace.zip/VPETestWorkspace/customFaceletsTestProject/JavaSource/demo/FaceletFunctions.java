package demo;

/**
 * @author mareshkau
 */
public class FaceletFunctions {

    /**
     * The private constructor.
     */
    private FaceletFunctions() {
	super();
	
    }
    
    /**

     */
    public static String getStringForDisplay(String test) {
		String rst = test;
		
		return rst;
    }
    
 
    
}
